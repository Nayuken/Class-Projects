import java.util.ArrayList;
import java.util.List;

public class Lsort<E> {
	public static <E extends Comparable<E>> int linearSearch(E[] list, E key){
		   
	    for(int i=0; i<list.length; i++){
	        if(list[i].compareTo(key) == 0) // found
	            return i;
	    }
	   
	    return -1; // not found
	}
public static void main(String[] args) {
	
	
	int[] arr1 = {20,22,35,60};
	int searchKey = 22;

	 //int sort = linearSearch(null, null);
	//System.out.println("key "+searchKey+ " found at index " +linearSearch(list, searchKey));
	
}

}
