import java.util.Random; import java.util.Scanner;

public class BubSort{ static int iterations=0;

static void bSort(int[] arr) { int n = arr.length; int temp = 0; for(int i=0; i < n; i++) { for(int j=1; j < (n-i); j++) { if(arr[j-1] > arr[j]) { 

iterations++; }
	}
}

} 
public static void main(String[] args) { 
	int randomnumber; 
	int runningtime=0; 
	int starttime=0;
	int endtime=0; 
	Random random=new Random();

Scanner read=new Scanner(System.in);
System.out.println("enter the size of the array"); 
int n=read.nextInt(); System.out.println("enter the number of arrays needing to be sorted"); 
int NU1=read.nextInt();

for(int i=0;i<NU1;i++) {

   int[] array=new int[n];
   for(int j=0;j<n;j++)
   {
   randomnumber = random.nextInt(100 + 1 - 1) + 1;


   }

   starttime=(int) System.nanoTime();
bSort(array); endtime=(int) System.nanoTime();

runningtime=runningtime+(endtime-starttime);
}

int AvgRT=runningtime/NU1;

System.out.println("number of units sorted: "+(n*NU1)); System.out.println("Total iterations :" +iterations); System.out.println("Average running time :"+AvgRT+" in miliseconds");

} }
