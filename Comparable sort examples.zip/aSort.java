import java.util.ArrayList;
public class aSort {

	public static void main(String[] args) {

		//Array of Integers

		Integer[] array1 = {205, 554, 231, 208, 3, 5};

		//display the array contents

		System.out.println("Integer array contents: ");

		display(array1);

		//find minmax in array

		MinMax(array1);

		  

		//Array of Doubles

		Double[] array2 = {133.4, 14.5, -1.1, 6.8, 200.0};

		//display the array contents

		System.out.println("Double array contents: ");

		display(array2);

		//find minmax in array

		MinMax(array2);

		}

		private static <E extends Comparable<E>> void display(E[] array) {

		  

		for(int i=0;i<array.length;i++)

		{

		System.out.print(array[i]+" ");

		}

		}

		public static <E extends Comparable<E>> void MinMax(E[] list)

		{

		E min = null;

		  

		for(E item:list){

		//assign first item as min

		if(min == null){

		min = item;

		continue;

		}

		//if any item less than min, set that item to min

		if(item.compareTo(min) < 0){

		min = item;

		}

		}

		System.out.println("\nMinimum value: "+min);

		  

		E max = null;

		for(E item:list){

		//assign first item as max

		if(max == null){

		max = item;

		continue;

		}

		//if any item greater than max, set that item to max

		if(item.compareTo(max) > 0){

		max = item;

		}

		}

		System.out.println("Maximum value: "+max);

		}  

		}

