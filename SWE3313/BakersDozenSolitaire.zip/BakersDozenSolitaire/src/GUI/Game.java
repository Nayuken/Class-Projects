/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.GridPane;

import javafx.stage.Stage;
import logic.Card;

public class Game extends Application {

    static List<Card> cardList = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {
        
        BorderPane layout = new BorderPane();
        
        final Menu menu1 = new Menu("New Game");
        final Menu menu2 = new Menu("Options");
        final Menu menu3 = new Menu("Help");
        MenuBar menuBar= new MenuBar();
        menuBar.getMenus().addAll(menu1,menu2,menu3);

        MouseGestures mg = new MouseGestures();

        Group root = new Group();
        Group root2 = new Group();
        
       Card input = new Card();
       Card input2 = new Card();
       Card input3 = new Card();
       
       VBox inputs = new VBox(3);
       inputs.getChildren().addAll(input,input2,input3);
       inputs.setSpacing(100);
       

        for( int i=0; i < 10; i++) {

            Card card = new Card();
            card.relocate( i * 20, i * 10);

            mg.makeDraggable(card);

            cardList.add( card);
        }
          
        
        GridPane deck = new GridPane();
    

        root.getChildren().addAll( cardList);
       // root2.getChildren().addAll(cardList);
        deck.add(root, 0, 0);
        //deck.add(root2,0,1);
        layout.setTop(menuBar);
        layout.setCenter(root);
        layout.setRight(inputs);
        BorderPane.setMargin(inputs, new Insets(25,100,25,0));
      
   
        
        
       
        Scene scene = new Scene(layout,1500,1500);

     

        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

   
    public static List<Card> getSelectedCards( Card currentCard) {

        List<Card> selectedCards = new ArrayList<>();

        int i = cardList.indexOf(currentCard);
        for( int j=i + 1; j < cardList.size(); j++) {
            selectedCards.add( cardList.get( j));
        }

        return selectedCards;
    }


}